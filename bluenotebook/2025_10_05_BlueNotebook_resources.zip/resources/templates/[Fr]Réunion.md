# Compte-rendu de réunion - {{date}}

______________________________________________________________

## Informations Générales

- **Sujet :** 
- **Date :** {{date}}
- **Heure :** {{horodatage}}
- **Lieu :** 

## Participants

- [ ] Participant 1
- [ ] Participant 2
- [ ] Participant 3

## Ordre du jour

1. Point 1
2. Point 2
3. Point 3

## Notes et Décisions

- 

## Actions à entreprendre

- [ ] **Action 1** - @Responsable - Pour le JJ/MM/AAAA
- [ ] **Action 2** - @Responsable - Pour le JJ/MM/AAAA