# Compte-rendu de Webconférence - {{date}}

______________________________________________________________

## Informations Générales

- **Titre :** 
- **Description :**
- **Animateurs :**
- **Date :** {{date}}
- **Heure :** {{horodatage}}
- **Plateforme :** 
- **Lien pour la connexion :**
- **Identifiants pour la connexion :**

## Participants

- [ ] Participant 1
- [ ] Participant 2
- [ ] Participant 3

## Ordre du jour

1. Point 1
2. Point 2
3. Point 3

## Points Clés & Décisions

- 
- 

## Actions à entreprendre

- [ ] **Action 1** - @Responsable - Pour le JJ/MM/AAAA
- [ ] **Action 2** - @Responsable - Pour le JJ/MM/AAAA

## A Retenir

1. Point 1
2. Point 2
3. Point 3

## Enregistrement

- **Lien vers l'enregistrement :** 